# 👶 Mãe pra Mãe - Sistema de Gestão de Brechó Infantil

Sistema completo para gestão de brechó infantil com controle de peças consignadas, vendas, pagamentos e parceiros.

## 🎨 Características

- **Design Infantil Minimalista**: Interface acolhedora e moderna com paleta de cores suaves
- **Autenticação**: Sistema de login para administradores e parceiros
- **Gestão de Peças**: Cadastro completo com fotos, códigos, marcas, tamanhos e valores
- **Controle de Status**: Filtros para peças disponíveis, vendidas e em curadoria
- **Vendas em Massa**: Página para registrar múltiplas vendas de uma vez
- **Pagamentos**: Controle de comissões de parceiros e geração de recibos
- **Configurações**: Gestão de marcas e tamanhos personalizáveis
- **Margem de Lucro**: Cálculo automático de margem percentual e absoluta

## 🛠️ Tecnologias Utilizadas

### Backend
- Node.js + Express
- Prisma ORM
- PostgreSQL
- JWT para autenticação
- Multer para upload de imagens
- bcryptjs para criptografia

### Frontend
- React 18
- React Router v6
- Axios
- React Icons
- CSS3 com design customizado

## 📋 Pré-requisitos

- Node.js 16+ instalado
- PostgreSQL instalado e rodando
- npm ou yarn

## 🚀 Instalação

### 1. Clone ou extraia o projeto

```bash
cd mae-pra-mae
```

### 2. Configurar o Backend

```bash
cd backend

# Instalar dependências
npm install

# Configurar variáveis de ambiente
cp .env.example .env
```

Edite o arquivo `.env` e configure:

```env
DATABASE_URL="postgresql://usuario:senha@localhost:5432/maeprамае?schema=public"
JWT_SECRET="sua-chave-secreta-super-segura-aqui"
PORT=3001
UPLOAD_DIR="./uploads"
```

**Importante**: Troque `usuario` e `senha` pelas credenciais do seu PostgreSQL.

```bash
# Criar banco de dados (se ainda não existe)
# No PostgreSQL, execute:
# CREATE DATABASE maeprامае;

# Executar migrations
npx prisma migrate dev --name init

# Gerar Prisma Client
npx prisma generate

# Iniciar servidor
npm run dev
```

O backend estará rodando em `http://localhost:3001`

### 3. Configurar o Frontend

Abra um novo terminal:

```bash
cd frontend

# Instalar dependências
npm install

# Configurar variáveis de ambiente
cp .env.example .env
```

O arquivo `.env` já vem configurado:

```env
REACT_APP_API_URL=http://localhost:3001/api
```

```bash
# Iniciar aplicação React
npm start
```

O frontend estará rodando em `http://localhost:3000`

## 🔑 Primeiro Acesso

### Criar usuário administrador

Use um cliente HTTP (Postman, Insomnia, curl) ou execute no terminal:

```bash
curl -X POST http://localhost:3001/api/auth/setup-admin \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "Administrador",
    "email": "admin@maeprامае.com",
    "senha": "admin123"
  }'
```

**Importante**: Esta rota só funciona se ainda não existir nenhum admin no sistema.

### Fazer Login

Acesse `http://localhost:3000` e faça login com:
- Email: `admin@maeprامае.com`
- Senha: `admin123`

**Recomendação**: Altere a senha após o primeiro acesso!

## 📱 Funcionalidades Detalhadas

### Para Administradores

1. **Dashboard**
   - Visão geral de todas as estatísticas
   - Total de peças, vendas e parceiros
   - Valores pendentes de pagamento

2. **Gestão de Peças**
   - Cadastrar novas peças com fotos
   - Editar informações
   - Filtrar por status (disponível/vendida/curadoria)
   - Visualizar margem de lucro

3. **Vendas**
   - Registrar vendas individuais
   - Baixa em massa de vendas
   - Histórico completo

4. **Pagamentos**
   - Ver pagamentos pendentes por parceiro
   - Marcar como pago em lote
   - Gerar recibos de pagamento

5. **Parceiros**
   - Cadastrar novos parceiros
   - Definir percentual de comissão
   - Gerenciar status ativo/inativo

6. **Configurações**
   - Cadastrar/editar marcas
   - Cadastrar/editar tamanhos
   - Ordenar tamanhos

### Para Parceiros

1. **Dashboard**
   - Visão das suas peças
   - Total a receber

2. **Minhas Peças**
   - Ver todas as peças consignadas
   - Status de cada peça

3. **Meus Pagamentos**
   - Pagamentos recebidos
   - Valores pendentes
   - Gerar recibos

## 🗂️ Estrutura do Banco de Dados

- **Usuario**: Dados de login (admin e parceiros)
- **Parceiro**: Informações adicionais dos parceiros
- **Marca**: Marcas de roupas (cadastro flexível)
- **Tamanho**: Tamanhos disponíveis (cadastro flexível)
- **Peca**: Peças do brechó (núcleo do sistema)
- **Venda**: Registro de vendas
- **Pagamento**: Controle de pagamentos aos parceiros

## 📊 Fluxo de Trabalho

1. **Cadastro de Parceiro** (Admin)
   - Nome, email, telefone, percentual

2. **Cadastro de Peça** (Admin)
   - Selecionar parceiro
   - Preencher dados (código, marca, tamanho, valores)
   - Upload de fotos
   - Definir status (disponível/curadoria)

3. **Venda de Peça** (Admin)
   - Registrar venda (individual ou em massa)
   - Sistema automaticamente:
     - Marca peça como vendida
     - Calcula valor do parceiro
     - Cria registro de pagamento pendente

4. **Pagamento ao Parceiro** (Admin)
   - Visualizar pagamentos pendentes
   - Selecionar e marcar como pago
   - Gerar recibo

5. **Consulta pelo Parceiro**
   - Ver suas peças e status
   - Ver pagamentos e recibos

## 🎨 Personalização

### Cores do Sistema

As cores podem ser alteradas no arquivo `frontend/src/index.css`:

```css
:root {
  --rosa-bebe: #FFB7C5;
  --azul-bebe: #B4D4FF;
  --verde-menta: #B8E6D5;
  /* ... outras cores ... */
}
```

### Fontes

O sistema usa:
- **Fredoka**: Títulos e logo (infantil e arredondada)
- **Nunito**: Corpo do texto (legível e amigável)

## 🔒 Segurança

- Senhas criptografadas com bcrypt
- Autenticação via JWT
- Validação de permissões (admin/parceiro)
- Upload de imagens validado (apenas imagens)
- Proteção contra SQL Injection (Prisma ORM)

## 📝 Status das Peças

- **disponivel**: Peça à venda no brechó
- **vendida**: Peça já vendida
- **curadoria**: Peça em análise/separação

## 💰 Cálculo de Valores

### Margem de Lucro
```
Margem Absoluta = Valor Venda - Valor Custo
Margem % = (Margem Absoluta / Valor Custo) × 100
```

### Pagamento ao Parceiro
```
Valor Parceiro = Valor Venda × (Percentual Parceiro / 100)
```

## 🐛 Solução de Problemas

### Erro de conexão com banco de dados
- Verifique se o PostgreSQL está rodando
- Confirme as credenciais no arquivo `.env`
- Execute: `npx prisma migrate reset` (⚠️ apaga todos os dados)

### Erro ao fazer upload de imagens
- Verifique permissões da pasta `backend/uploads`
- Limite de 5MB por imagem

### Token inválido
- Faça logout e login novamente
- Verifique se JWT_SECRET é o mesmo no backend

## 🚀 Deploy (Produção)

### Backend
1. Configure variáveis de ambiente no servidor
2. Use PostgreSQL em produção
3. Configure CORS adequadamente
4. Use PM2 ou similar para manter o servidor rodando

### Frontend
1. Execute `npm run build` na pasta frontend
2. Sirva os arquivos estáticos gerados em `build/`
3. Configure variável REACT_APP_API_URL para o backend em produção

## 📞 Suporte

Para dúvidas ou problemas:
1. Verifique os logs do terminal (backend e frontend)
2. Use `npx prisma studio` para visualizar o banco de dados
3. Confira as configurações do `.env`

## 📄 Licença

Sistema desenvolvido para uso em brechós infantis.

---

**Desenvolvido com 💗 para o Mãe pra Mãe**
