# 🚀 GUIA RÁPIDO DE INÍCIO

## ⚡ Instalação Rápida

### 1. Backend (Terminal 1)

```bash
cd backend
npm install
cp .env.example .env
```

**Edite o arquivo `.env` com suas credenciais do PostgreSQL**

```bash
npx prisma migrate dev --name init
npx prisma generate
npm run dev
```

### 2. Frontend (Terminal 2)

```bash
cd frontend
npm install
npm start
```

### 3. Criar Admin

```bash
curl -X POST http://localhost:3001/api/auth/setup-admin \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "Admin",
    "email": "admin@test.com",
    "senha": "admin123"
  }'
```

### 4. Acessar Sistema

Abra: `http://localhost:3000`

Login:
- Email: `admin@test.com`
- Senha: `admin123`

---

## 📋 Checklist Pós-Instalação

- [ ] Backend rodando em http://localhost:3001
- [ ] Frontend rodando em http://localhost:3000
- [ ] Admin criado com sucesso
- [ ] Login funcionando
- [ ] Dashboard carregando

---

## 🎯 Primeiros Passos

1. **Configurar Marcas e Tamanhos**
   - Ir em Configurações
   - Adicionar marcas comuns (ex: Carters, Gap, Zara Kids)
   - Adicionar tamanhos (ex: RN, P, M, G, 1, 2, 3, 4...)

2. **Cadastrar Parceiros**
   - Ir em Parceiros
   - Adicionar novos parceiros
   - Definir percentual de comissão (padrão: 50%)

3. **Cadastrar Peças**
   - Ir em Peças
   - Nova Peça
   - Preencher dados e fazer upload de fotos

4. **Registrar Vendas**
   - Ir em Vendas
   - Registrar vendas individuais ou em massa

5. **Gerenciar Pagamentos**
   - Ir em Pagamentos
   - Ver pendentes por parceiro
   - Marcar como pago
   - Gerar recibos

---

## 🆘 Problemas Comuns

### "Erro ao conectar ao banco de dados"
→ Verifique se PostgreSQL está rodando
→ Confirme credenciais no .env

### "Token inválido" ou erro de autenticação
→ Faça logout e login novamente
→ Limpe localStorage do navegador

### "Cannot find module..."
→ Execute `npm install` novamente

### Porta já em uso
→ Mude a PORT no .env do backend
→ Atualize REACT_APP_API_URL no frontend

---

## 📱 Funcionalidades Principais

### Admin pode:
✅ Gerenciar todas as peças
✅ Cadastrar parceiros
✅ Registrar vendas
✅ Controlar pagamentos
✅ Configurar marcas e tamanhos
✅ Ver todas as estatísticas

### Parceiro pode:
✅ Ver suas peças
✅ Acompanhar vendas
✅ Ver pagamentos pendentes
✅ Gerar recibos

---

## 💡 Dicas

- Use códigos únicos para as etiquetas (ex: MAE001, MAE002...)
- Tire fotos claras das peças antes de cadastrar
- Mantenha as marcas e tamanhos organizados
- Faça backup regular do banco de dados
- Use a baixa em massa para agilizar vendas

---

**Pronto para começar! 🎉**

Para mais detalhes, consulte o README.md completo.
