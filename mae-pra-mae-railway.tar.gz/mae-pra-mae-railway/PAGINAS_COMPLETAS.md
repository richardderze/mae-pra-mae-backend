# PÁGINAS COMPLETAS ADICIONAIS
# Cole cada componente no arquivo correspondente

## ==== frontend/src/pages/Pecas.js ====

import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { FiPlus, FiEdit2, FiTrash2, FiFilter, FiSearch, FiX } from 'react-icons/fi';

const Pecas = () => {
  const [pecas, setPecas] = useState([]);
  const [marcas, setMarcas] = useState([]);
  const [tamanhos, setTamanhos] = useState([]);
  const [parceiros, setParceiros] = useState([]);
  const [filtroStatus, setFiltroStatus] = useState('');
  const [busca, setBusca] = useState('');
  const [modalAberto, setModalAberto] = useState(false);
  const [pecaEditando, setPecaEditando] = useState(null);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    carregarDados();
  }, [filtroStatus]);

  const carregarDados = async () => {
    try {
      setCarregando(true);
      const [pecasRes, marcasRes, tamanhosRes, parceirosRes] = await Promise.all([
        api.get(`/pecas${filtroStatus ? `?status=${filtroStatus}` : ''}`),
        api.get('/marcas'),
        api.get('/tamanhos'),
        api.get('/parceiros')
      ]);

      setPecas(pecasRes.data);
      setMarcas(marcasRes.data);
      setTamanhos(tamanhosRes.data);
      setParceiros(parceirosRes.data);
    } catch (erro) {
      console.error('Erro ao carregar dados:', erro);
    } finally {
      setCarregando(false);
    }
  };

  const pecasFiltradas = pecas.filter(peca =>
    peca.codigoEtiqueta.toLowerCase().includes(busca.toLowerCase()) ||
    peca.marca.nome.toLowerCase().includes(busca.toLowerCase())
  );

  const abrirModal = (peca = null) => {
    setPecaEditando(peca);
    setModalAberto(true);
  };

  const fecharModal = () => {
    setPecaEditando(null);
    setModalAberto(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    try {
      if (pecaEditando) {
        await api.put(`/pecas/${pecaEditando.id}`, formData);
      } else {
        await api.post('/pecas', formData);
      }
      fecharModal();
      carregarDados();
    } catch (erro) {
      console.error('Erro ao salvar peça:', erro);
      alert('Erro ao salvar peça');
    }
  };

  const deletarPeca = async (id) => {
    if (!window.confirm('Deseja realmente deletar esta peça?')) return;

    try {
      await api.delete(`/pecas/${id}`);
      carregarDados();
    } catch (erro) {
      console.error('Erro ao deletar:', erro);
      alert('Erro ao deletar peça');
    }
  };

  if (carregando) {
    return <div className="loading"><div className="spinner"></div></div>;
  }

  return (
    <div>
      <div className="page-header">
        <h1>Gestão de Peças</h1>
        <button className="btn btn-primary" onClick={() => abrirModal()}>
          <FiPlus /> Nova Peça
        </button>
      </div>

      <div className="filters-bar">
        <div className="search-box">
          <FiSearch />
          <input
            type="text"
            placeholder="Buscar por código ou marca..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
          />
        </div>

        <div className="filter-buttons">
          <button
            className={`filter-btn ${filtroStatus === '' ? 'active' : ''}`}
            onClick={() => setFiltroStatus('')}
          >
            Todas
          </button>
          <button
            className={`filter-btn ${filtroStatus === 'disponivel' ? 'active' : ''}`}
            onClick={() => setFiltroStatus('disponivel')}
          >
            Disponíveis
          </button>
          <button
            className={`filter-btn ${filtroStatus === 'vendida' ? 'active' : ''}`}
            onClick={() => setFiltroStatus('vendida')}
          >
            Vendidas
          </button>
          <button
            className={`filter-btn ${filtroStatus === 'curadoria' ? 'active' : ''}`}
            onClick={() => setFiltroStatus('curadoria')}
          >
            Curadoria
          </button>
        </div>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Código</th>
              <th>Marca</th>
              <th>Tamanho</th>
              <th>Parceiro</th>
              <th>Custo</th>
              <th>Venda</th>
              <th>Margem %</th>
              <th>Margem R$</th>
              <th>Status</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {pecasFiltradas.map(peca => (
              <tr key={peca.id}>
                <td>{peca.codigoEtiqueta}</td>
                <td>{peca.marca.nome}</td>
                <td>{peca.tamanho.nome}</td>
                <td>{peca.parceiro.usuario.nome}</td>
                <td>R$ {peca.valorCusto.toFixed(2)}</td>
                <td>R$ {peca.valorVenda.toFixed(2)}</td>
                <td>{peca.margemPercentual}%</td>
                <td>R$ {peca.margemAbsoluta}</td>
                <td>
                  <span className={`badge badge-${peca.status}`}>
                    {peca.status}
                  </span>
                </td>
                <td>
                  <button className="btn-icon" onClick={() => abrirModal(peca)}>
                    <FiEdit2 />
                  </button>
                  <button className="btn-icon danger" onClick={() => deletarPeca(peca.id)}>
                    <FiTrash2 />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal de Cadastro/Edição */}
      {modalAberto && (
        <div className="modal-overlay" onClick={fecharModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{pecaEditando ? 'Editar Peça' : 'Nova Peça'}</h2>
              <button className="btn-close" onClick={fecharModal}>
                <FiX />
              </button>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="form-row">
                <div className="form-group">
                  <label>Código Etiqueta *</label>
                  <input
                    type="text"
                    name="codigoEtiqueta"
                    className="form-control"
                    defaultValue={pecaEditando?.codigoEtiqueta}
                    required
                  />
                </div>

                <div className="form-group">
                  <label>Parceiro *</label>
                  <select
                    name="parceiroId"
                    className="form-control"
                    defaultValue={pecaEditando?.parceiroId}
                    required
                  >
                    <option value="">Selecione...</option>
                    {parceiros.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.usuario.nome}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Marca *</label>
                  <select
                    name="marcaId"
                    className="form-control"
                    defaultValue={pecaEditando?.marcaId}
                    required
                  >
                    <option value="">Selecione...</option>
                    {marcas.map(m => (
                      <option key={m.id} value={m.id}>{m.nome}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>Tamanho *</label>
                  <select
                    name="tamanhoId"
                    className="form-control"
                    defaultValue={pecaEditando?.tamanhoId}
                    required
                  >
                    <option value="">Selecione...</option>
                    {tamanhos.map(t => (
                      <option key={t.id} value={t.id}>{t.nome}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Valor de Custo *</label>
                  <input
                    type="number"
                    step="0.01"
                    name="valorCusto"
                    className="form-control"
                    defaultValue={pecaEditando?.valorCusto}
                    required
                  />
                </div>

                <div className="form-group">
                  <label>Valor de Venda *</label>
                  <input
                    type="number"
                    step="0.01"
                    name="valorVenda"
                    className="form-control"
                    defaultValue={pecaEditando?.valorVenda}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label>Status *</label>
                <select
                  name="status"
                  className="form-control"
                  defaultValue={pecaEditando?.status || 'disponivel'}
                  required
                >
                  <option value="disponivel">Disponível</option>
                  <option value="curadoria">Em Curadoria</option>
                  <option value="vendida">Vendida</option>
                </select>
              </div>

              <div className="form-group">
                <label>Fotos</label>
                <input
                  type="file"
                  name="fotos"
                  className="form-control"
                  accept="image/*"
                  multiple
                />
              </div>

              <div className="form-group">
                <label>Observações</label>
                <textarea
                  name="observacoes"
                  className="form-control"
                  defaultValue={pecaEditando?.observacoes}
                ></textarea>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-outline" onClick={fecharModal}>
                  Cancelar
                </button>
                <button type="submit" className="btn btn-primary">
                  Salvar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Pecas;


## ==== frontend/src/pages/VendasMassa.js ====

import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { FiPlus, FiTrash2, FiSave } from 'react-icons/fi';

const VendasMassa = () => {
  const [pecasDisponiveis, setPecasDisponiveis] = useState([]);
  const [itensSelecionados, setItensSelecionados] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    carregarPecas();
  }, []);

  const carregarPecas = async () => {
    try {
      const response = await api.get('/pecas?status=disponivel');
      setPecasDisponiveis(response.data);
    } catch (erro) {
      console.error('Erro ao carregar peças:', erro);
    } finally {
      setCarregando(false);
    }
  };

  const adicionarItem = () => {
    setItensSelecionados([
      ...itensSelecionados,
      { pecaId: '', valorVendido: '' }
    ]);
  };

  const removerItem = (index) => {
    setItensSelecionados(itensSelecionados.filter((_, i) => i !== index));
  };

  const atualizarItem = (index, campo, valor) => {
    const novosItens = [...itensSelecionados];
    novosItens[index][campo] = valor;

    // Auto-preencher valor se selecionou peça
    if (campo === 'pecaId' && valor) {
      const peca = pecasDisponiveis.find(p => p.id === parseInt(valor));
      if (peca) {
        novosItens[index].valorVendido = peca.valorVenda.toFixed(2);
      }
    }

    setItensSelecionados(novosItens);
  };

  const registrarVendas = async () => {
    if (itensSelecionados.length === 0) {
      alert('Adicione pelo menos uma peça para vender');
      return;
    }

    const vendasValidas = itensSelecionados.filter(
      item => item.pecaId && item.valorVendido
    );

    if (vendasValidas.length === 0) {
      alert('Preencha todos os campos das vendas');
      return;
    }

    try {
      const response = await api.post('/vendas/massa', {
        vendas: vendasValidas.map(item => ({
          pecaId: parseInt(item.pecaId),
          valorVendido: parseFloat(item.valorVendido)
        }))
      });

      alert(`${response.data.sucesso} vendas registradas com sucesso!`);
      setItensSelecionados([]);
      carregarPecas();
    } catch (erro) {
      console.error('Erro ao registrar vendas:', erro);
      alert('Erro ao registrar vendas');
    }
  };

  if (carregando) {
    return <div className="loading"><div className="spinner"></div></div>;
  }

  return (
    <div>
      <div className="page-header">
        <h1>Baixa de Vendas em Massa</h1>
        <button className="btn btn-success" onClick={registrarVendas}>
          <FiSave /> Registrar Todas
        </button>
      </div>

      <div className="card">
        <button className="btn btn-primary" onClick={adicionarItem}>
          <FiPlus /> Adicionar Item
        </button>

        {itensSelecionados.length === 0 ? (
          <p className="empty-state">
            Nenhum item adicionado. Clique em "Adicionar Item" para começar.
          </p>
        ) : (
          <div className="vendas-lista">
            {itensSelecionados.map((item, index) => (
              <div key={index} className="venda-item">
                <div className="venda-numero">#{index + 1}</div>

                <div className="form-row">
                  <div className="form-group flex-1">
                    <label>Peça</label>
                    <select
                      className="form-control"
                      value={item.pecaId}
                      onChange={(e) => atualizarItem(index, 'pecaId', e.target.value)}
                    >
                      <option value="">Selecione a peça...</option>
                      {pecasDisponiveis.map(peca => (
                        <option key={peca.id} value={peca.id}>
                          {peca.codigoEtiqueta} - {peca.marca.nome} - Tam. {peca.tamanho.nome} - R$ {peca.valorVenda.toFixed(2)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="form-group" style={{width: '150px'}}>
                    <label>Valor Vendido</label>
                    <input
                      type="number"
                      step="0.01"
                      className="form-control"
                      value={item.valorVendido}
                      onChange={(e) => atualizarItem(index, 'valorVendido', e.target.value)}
                    />
                  </div>

                  <button
                    className="btn-icon danger"
                    onClick={() => removerItem(index)}
                    style={{alignSelf: 'flex-end'}}
                  >
                    <FiTrash2 />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default VendasMassa;

## ==== ESTILOS ADICIONAIS ====

/* Adicione ao final do arquivo frontend/src/index.css */

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.filters-bar {
  display: flex;
  gap: 16px;
  margin-bottom: 24px;
  flex-wrap: wrap;
}

.search-box {
  flex: 1;
  min-width: 250px;
  display: flex;
  align-items: center;
  gap: 12px;
  background: white;
  padding: 12px 16px;
  border-radius: var(--radius-full);
  box-shadow: var(--sombra-sm);
}

.search-box input {
  border: none;
  outline: none;
  flex: 1;
  font-size: 1rem;
}

.filter-buttons {
  display: flex;
  gap: 8px;
}

.filter-btn {
  padding: 10px 20px;
  border: 2px solid var(--cinza-medio);
  background: white;
  border-radius: var(--radius-full);
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s;
}

.filter-btn.active {
  background: var(--rosa-bebe);
  border-color: var(--rosa-bebe);
  color: white;
}

.btn-icon {
  background: none;
  border: none;
  padding: 8px;
  cursor: pointer;
  color: var(--texto-secundario);
  transition: color 0.3s;
}

.btn-icon:hover {
  color: var(--rosa-bebe);
}

.btn-icon.danger:hover {
  color: var(--erro);
}

/* Modal */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: 20px;
}

.modal-content {
  background: white;
  border-radius: var(--radius-lg);
  max-width: 600px;
  width: 100%;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: var(--sombra-lg);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px;
  border-bottom: 2px solid var(--cinza-medio);
}

.modal-header h2 {
  margin: 0;
}

.btn-close {
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  color: var(--texto-secundario);
}

.modal-content form {
  padding: 24px;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding: 24px;
  border-top: 2px solid var(--cinza-medio);
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.flex-1 {
  flex: 1;
}

.venda-item {
  background: var(--cinza-claro);
  padding: 16px;
  border-radius: var(--radius-md);
  margin-bottom: 16px;
}

.venda-numero {
  font-weight: 700;
  color: var(--rosa-bebe);
  margin-bottom: 12px;
}

.empty-state {
  text-align: center;
  padding: 40px;
  color: var(--texto-secundario);
}
