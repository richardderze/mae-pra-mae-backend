# 🚀 GUIA COMPLETO - DEPLOY NO RAILWAY.APP

## ✨ Por que Railway?

- ✅ **100% Gratuito** para começar ($5 de crédito mensal)
- ✅ **PostgreSQL incluído** (não precisa configurar banco separado)
- ✅ **Deploy automático** via GitHub
- ✅ **HTTPS automático** (certificado SSL gratuito)
- ✅ **Mais fácil que cPanel** - literalmente 3 cliques!

---

## 📋 PASSO 1: Criar Conta no Railway

1. Acesse: **https://railway.app**
2. Clique em **"Login"** ou **"Start a New Project"**
3. Faça login com sua conta:
   - **GitHub** (recomendado) - mais fácil para deploy
   - OU Google
   - OU Email

4. Após login, você verá o Dashboard do Railway

---

## 📋 PASSO 2: Criar Conta no GitHub (se ainda não tiver)

**Se você JÁ tem conta GitHub, pule para o Passo 3!**

1. Acesse: **https://github.com**
2. Clique em **"Sign up"**
3. Crie sua conta (é gratuito)
4. Confirme seu email

---

## 📋 PASSO 3: Fazer Upload do Projeto no GitHub

### Opção A: Via Interface Web do GitHub (MAIS FÁCIL)

1. **No GitHub**, clique no **"+"** no canto superior direito
2. Selecione **"New repository"**
3. Preencha:
   - **Repository name:** `mae-pra-mae`
   - **Description:** "Sistema de gestão de brechó infantil"
   - Deixe **Public** (pode ser Private também)
   - ✅ Marque **"Add a README file"**
4. Clique em **"Create repository"**

5. **Agora vamos fazer upload dos arquivos:**
   - No repositório criado, clique em **"Add file"** → **"Upload files"**
   - **Arraste apenas a pasta `backend`** do projeto `mae-pra-mae-railway`
   - Ou clique em "choose your files" e selecione TODOS os arquivos de dentro da pasta `backend/`
   - Na caixa de commit, escreva: "Backend inicial"
   - Clique em **"Commit changes"**

### Opção B: Via Git (Se você conhece Git)

```bash
# No terminal/Git Bash
git init
git add backend/
git commit -m "Backend inicial"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/mae-pra-mae.git
git push -u origin main
```

---

## 📋 PASSO 4: Deploy do Backend no Railway

### 4.1 - Criar Novo Projeto

1. No **Railway Dashboard**, clique em **"New Project"**
2. Selecione **"Deploy from GitHub repo"**
3. Se pedir autorização, clique em **"Configure GitHub App"**
4. Selecione o repositório **`mae-pra-mae`**
5. Clique em **"Deploy Now"**

### 4.2 - Adicionar PostgreSQL

1. No projeto criado, clique em **"+ New"**
2. Selecione **"Database"**
3. Escolha **"Add PostgreSQL"**
4. Aguarde alguns segundos - o banco será criado automaticamente! ✅

### 4.3 - Configurar Variáveis de Ambiente

1. Clique no **serviço do backend** (não no banco)
2. Vá na aba **"Variables"**
3. Clique em **"+ New Variable"**
4. Adicione estas variáveis **UMA POR VEZ**:

**Variable 1:**
- **Name:** `DATABASE_URL`
- **Value:** Clique em **"Add Reference"** → Selecione o PostgreSQL → Escolha `DATABASE_URL`

**Variable 2:**
- **Name:** `JWT_SECRET`
- **Value:** `mae-pra-mae-2026-chave-secreta-railway-123456789`

**Variable 3:**
- **Name:** `PORT`
- **Value:** `3001`

**Variable 4:**
- **Name:** `UPLOAD_DIR`
- **Value:** `./uploads`

5. Clique em **"Deploy"** (ou aguarde o redeploy automático)

### 4.4 - Configurar Root Directory

1. No serviço do backend, vá em **"Settings"**
2. Procure por **"Root Directory"** ou **"Service Root"**
3. Digite: `backend`
4. Salve

### 4.5 - Aguardar Deploy

- O Railway vai:
  - ✅ Instalar dependências (`npm install`)
  - ✅ Gerar Prisma Client
  - ✅ Executar migrations do banco
  - ✅ Iniciar o servidor

- Isso leva **2-5 minutos**
- Você pode acompanhar os logs em **"Deployments"** → Último deploy → **"View Logs"**

### 4.6 - Obter URL do Backend

1. No serviço do backend, vá em **"Settings"**
2. Procure por **"Domains"** ou **"Public Networking"**
3. Clique em **"Generate Domain"**
4. Será gerada uma URL tipo: `https://seu-app.up.railway.app`
5. **COPIE ESSA URL** - você vai precisar!

### 4.7 - Testar Backend

Abra no navegador:
```
https://seu-app.up.railway.app/api/health
```

Deve retornar:
```json
{
  "status": "ok",
  "message": "API Mãe pra Mãe funcionando!"
}
```

✅ **SE DEU CERTO = BACKEND ESTÁ NO AR!** 🎉

---

## 📋 PASSO 5: Criar Usuário Admin

### Via Terminal (se tiver curl):

```bash
curl -X POST https://seu-app.up.railway.app/api/auth/setup-admin \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "Administrador",
    "email": "admin@maeprामае.com",
    "senha": "admin123"
  }'
```

### Via Postman/Insomnia:

- **Method:** POST
- **URL:** `https://seu-app.up.railway.app/api/auth/setup-admin`
- **Headers:** `Content-Type: application/json`
- **Body (JSON):**
```json
{
  "nome": "Administrador",
  "email": "admin@maeprамає.com",
  "senha": "admin123"
}
```

### Via Thunder Client (extensão do VS Code):

1. Instale Thunder Client no VS Code
2. Nova Request → POST
3. URL: `https://seu-app.up.railway.app/api/auth/setup-admin`
4. Body → JSON → Cole o JSON acima
5. Send

**Deve retornar:**
```json
{
  "mensagem": "Admin criado com sucesso"
}
```

---

## 📋 PASSO 6: Deploy do Frontend

Agora vamos colocar o frontend no ar!

### Opção 1: Vercel (RECOMENDADO - Gratuito)

1. **Acesse:** https://vercel.com
2. **Faça login** com GitHub
3. Clique em **"Add New..."** → **"Project"**
4. Selecione o repositório `mae-pra-mae`
5. **Configure:**
   - **Framework Preset:** Create React App
   - **Root Directory:** `frontend`
   - **Build Command:** `npm run build`
   - **Output Directory:** `build`
6. Em **"Environment Variables"** adicione:
   - **Name:** `REACT_APP_API_URL`
   - **Value:** `https://seu-app.up.railway.app/api` (URL do Railway)
7. Clique em **"Deploy"**
8. Aguarde 2-3 minutos
9. Vercel vai gerar uma URL: `https://mae-pra-mae.vercel.app`

### Opção 2: Netlify (Alternativa gratuita)

1. **Acesse:** https://netlify.com
2. **Faça login** com GitHub
3. **"Add new site"** → **"Import an existing project"**
4. Conecte GitHub → Selecione `mae-pra-mae`
5. **Configure:**
   - **Base directory:** `frontend`
   - **Build command:** `npm run build`
   - **Publish directory:** `build`
6. **Environment variables:**
   - `REACT_APP_API_URL` = `https://seu-app.up.railway.app/api`
7. **Deploy**

### Opção 3: Railway (Tudo no mesmo lugar)

1. No Railway, no mesmo projeto, clique em **"+ New"**
2. **"GitHub Repo"** → Selecione `mae-pra-mae` novamente
3. Configure Root Directory: `frontend`
4. Adicione variável `REACT_APP_API_URL`
5. Em Settings, adicione Build Command: `npm run build`
6. Start Command: `npx serve -s build -l 3000`
7. Generate Domain

---

## 📋 PASSO 7: Acessar o Sistema

1. **Acesse a URL do frontend** (Vercel/Netlify/Railway)
2. **Faça login:**
   - Email: `admin@maeprамає.com`
   - Senha: `admin123`
3. **Configure o sistema:**
   - Vá em "Configurações"
   - Adicione marcas
   - Adicione tamanhos
   - Cadastre parceiros
4. **Comece a usar!** 🎉

---

## 🎯 URLs Finais

Após tudo configurado, você terá:

- **Backend:** `https://seu-app.up.railway.app`
- **Frontend:** `https://mae-pra-mae.vercel.app` (ou Netlify)
- **Banco:** PostgreSQL no Railway (gerenciado automaticamente)

---

## 💰 Custos

- **Railway:** Gratuito até $5/mês de uso (mais que suficiente para começar)
- **Vercel/Netlify:** 100% gratuito
- **GitHub:** 100% gratuito (repositórios públicos)

**Total: R$ 0,00** para começar! 🎉

---

## 🐛 Solução de Problemas

### Backend não sobe no Railway

**Verificar logs:**
1. Railway → Seu projeto → Backend
2. Aba "Deployments"
3. Clique no último deploy
4. "View Logs"

**Erros comuns:**
- Database connection error → Verifique se DATABASE_URL está referenciando o Postgres
- Port error → Certifique-se que PORT está configurado
- Build error → Verifique se Root Directory está em `backend`

### Frontend não conecta no backend

**Verificar:**
- ✅ `REACT_APP_API_URL` está correta (com /api no final)
- ✅ Backend está funcionando (teste /api/health)
- ✅ Sem erro de CORS (já está configurado no código)

### Admin não é criado

- Verifique se a rota setup-admin está retornando erro
- Tente via Postman/Insomnia para ver o erro completo
- Se já existe admin, a rota retorna erro (isso é normal)

---

## 📞 Próximos Passos

Após tudo funcionando:

1. ✅ Adicione marcas e tamanhos
2. ✅ Cadastre parceiros
3. ✅ Comece a adicionar peças
4. ✅ Registre vendas
5. ✅ Gere recibos

---

## 🎓 Dicas de Uso no Railway

- **Ver logs:** Deployments → View Logs
- **Reiniciar:** Settings → Restart
- **Monitorar:** Metrics (veja uso de recursos)
- **Backup banco:** Database → Connect → Use credentials para backup manual

---

**Pronto! Seu sistema está no ar! 🚀👶💗**

Muito mais simples que cPanel, né? 😊
