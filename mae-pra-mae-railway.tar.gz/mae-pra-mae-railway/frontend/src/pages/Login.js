import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { FiMail, FiLock, FiHeart } from 'react-icons/fi';
import './Login.css';

const Login = () => {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErro('');
    setCarregando(true);

    const resultado = await login(email, senha);

    if (resultado.sucesso) {
      navigate('/dashboard');
    } else {
      setErro(resultado.mensagem);
    }

    setCarregando(false);
  };

  return (
    <div className="login-container">
      <div className="login-decoration">
        <div className="floating-shape shape-1"></div>
        <div className="floating-shape shape-2"></div>
        <div className="floating-shape shape-3"></div>
      </div>

      <div className="login-card fade-in">
        <div className="login-header">
          <h1 className="login-logo">
            👶 Mãe pra Mãe
          </h1>
          <p className="login-subtitle">
            <FiHeart className="heart-icon" />
            Brechó Infantil com Amor
          </p>
        </div>

        {erro && (
          <div className="alert alert-error">
            {erro}
          </div>
        )}

        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label className="form-label">
              <FiMail size={18} />
              Email
            </label>
            <input
              type="email"
              className="form-control"
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">
              <FiLock size={18} />
              Senha
            </label>
            <input
              type="password"
              className="form-control"
              placeholder="••••••••"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              required
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary btn-login"
            disabled={carregando}
          >
            {carregando ? (
              <>
                <div className="spinner-small"></div>
                Entrando...
              </>
            ) : (
              'Entrar'
            )}
          </button>
        </form>

        <div className="login-footer">
          <p>Sistema de Gestão de Brechó Infantil</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
