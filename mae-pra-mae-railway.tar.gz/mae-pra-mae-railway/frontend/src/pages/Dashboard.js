import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { 
  FiShoppingBag, FiDollarSign, FiTrendingUp, 
  FiPackage, FiUsers, FiAlertCircle 
} from 'react-icons/fi';
import './Dashboard.css';

const Dashboard = () => {
  const { isAdmin, usuario } = useAuth();
  const [estatisticas, setEstatisticas] = useState({
    totalPecas: 0,
    pecasDisponiveis: 0,
    pecasVendidas: 0,
    pecasCuradoria: 0,
    totalVendas: 0,
    totalPendente: 0,
    totalParceiros: 0
  });
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    try {
      setCarregando(true);

      if (isAdmin()) {
        // Dados para Admin
        const [pecasRes, vendasRes, parceirosRes, pagamentosRes] = await Promise.all([
          api.get('/pecas'),
          api.get('/vendas'),
          api.get('/parceiros'),
          api.get('/pagamentos?pago=false')
        ]);

        const pecas = pecasRes.data;
        const totalVendas = vendasRes.data.reduce((acc, v) => acc + v.valorVendido, 0);
        const totalPendente = pagamentosRes.data.reduce((acc, p) => acc + p.valorParceiro, 0);

        setEstatisticas({
          totalPecas: pecas.length,
          pecasDisponiveis: pecas.filter(p => p.status === 'disponivel').length,
          pecasVendidas: pecas.filter(p => p.status === 'vendida').length,
          pecasCuradoria: pecas.filter(p => p.status === 'curadoria').length,
          totalVendas,
          totalPendente,
          totalParceiros: parceirosRes.data.length
        });
      } else {
        // Dados para Parceiro
        const [pecasRes, pagamentosRes] = await Promise.all([
          api.get(`/pecas?parceiroId=${usuario.parceiroId}`),
          api.get(`/pagamentos/pendentes/${usuario.parceiroId}`)
        ]);

        const pecas = pecasRes.data;

        setEstatisticas({
          totalPecas: pecas.length,
          pecasDisponiveis: pecas.filter(p => p.status === 'disponivel').length,
          pecasVendidas: pecas.filter(p => p.status === 'vendida').length,
          pecasCuradoria: pecas.filter(p => p.status === 'curadoria').length,
          totalPendente: pagamentosRes.data.total,
          quantidadePendente: pagamentosRes.data.quantidade
        });
      }
    } catch (erro) {
      console.error('Erro ao carregar dados:', erro);
    } finally {
      setCarregando(false);
    }
  };

  if (carregando) {
    return (
      <div className="loading">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Dashboard</h1>
        <p className="subtitulo">Visão geral do {isAdmin() ? 'brechó' : 'seu estoque'}</p>
      </div>

      <div className="cards-grid">
        <div className="stat-card card-rosa">
          <div className="stat-icon">
            <FiShoppingBag size={32} />
          </div>
          <div className="stat-info">
            <h3>{estatisticas.totalPecas}</h3>
            <p>Total de Peças</p>
          </div>
        </div>

        <div className="stat-card card-verde">
          <div className="stat-icon">
            <FiPackage size={32} />
          </div>
          <div className="stat-info">
            <h3>{estatisticas.pecasDisponiveis}</h3>
            <p>Disponíveis</p>
          </div>
        </div>

        <div className="stat-card card-azul">
          <div className="stat-icon">
            <FiTrendingUp size={32} />
          </div>
          <div className="stat-info">
            <h3>{estatisticas.pecasVendidas}</h3>
            <p>Vendidas</p>
          </div>
        </div>

        <div className="stat-card card-amarelo">
          <div className="stat-icon">
            <FiAlertCircle size={32} />
          </div>
          <div className="stat-info">
            <h3>{estatisticas.pecasCuradoria}</h3>
            <p>Em Curadoria</p>
          </div>
        </div>

        {isAdmin() && (
          <>
            <div className="stat-card card-dinheiro">
              <div className="stat-icon">
                <FiDollarSign size={32} />
              </div>
              <div className="stat-info">
                <h3>R$ {estatisticas.totalVendas.toFixed(2)}</h3>
                <p>Total em Vendas</p>
              </div>
            </div>

            <div className="stat-card card-pendente">
              <div className="stat-icon">
                <FiDollarSign size={32} />
              </div>
              <div className="stat-info">
                <h3>R$ {estatisticas.totalPendente.toFixed(2)}</h3>
                <p>Pagamentos Pendentes</p>
              </div>
            </div>

            <div className="stat-card card-parceiros">
              <div className="stat-icon">
                <FiUsers size={32} />
              </div>
              <div className="stat-info">
                <h3>{estatisticas.totalParceiros}</h3>
                <p>Parceiros Ativos</p>
              </div>
            </div>
          </>
        )}

        {!isAdmin() && (
          <div className="stat-card card-pendente">
            <div className="stat-icon">
              <FiDollarSign size={32} />
            </div>
            <div className="stat-info">
              <h3>R$ {estatisticas.totalPendente?.toFixed(2) || '0.00'}</h3>
              <p>A Receber ({estatisticas.quantidadePendente || 0} peças)</p>
            </div>
          </div>
        )}
      </div>

      <div className="dashboard-info">
        <div className="card info-card">
          <h3>📊 Resumo</h3>
          <p>
            {isAdmin() 
              ? `Você tem ${estatisticas.pecasDisponiveis} peças disponíveis para venda, ${estatisticas.pecasCuradoria} em curadoria e ${estatisticas.pecasVendidas} já vendidas.`
              : `Você tem ${estatisticas.pecasDisponiveis} peças disponíveis, ${estatisticas.pecasCuradoria} em curadoria e ${estatisticas.pecasVendidas} já vendidas.`
            }
          </p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
