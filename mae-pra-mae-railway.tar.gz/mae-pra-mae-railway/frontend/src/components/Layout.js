import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  FiHome, FiShoppingBag, FiUsers, FiDollarSign, 
  FiTag, FiTrendingUp, FiLogOut, FiMenu 
} from 'react-icons/fi';
import './Layout.css';

const Layout = ({ children }) => {
  const { usuario, logout, isAdmin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuAberto, setMenuAberto] = React.useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const menuItens = isAdmin() ? [
    { path: '/dashboard', icon: FiHome, label: 'Dashboard' },
    { path: '/pecas', icon: FiShoppingBag, label: 'Peças' },
    { path: '/vendas', icon: FiTrendingUp, label: 'Vendas' },
    { path: '/pagamentos', icon: FiDollarSign, label: 'Pagamentos' },
    { path: '/parceiros', icon: FiUsers, label: 'Parceiros' },
    { path: '/configuracoes', icon: FiTag, label: 'Configurações' },
  ] : [
    { path: '/dashboard', icon: FiHome, label: 'Dashboard' },
    { path: '/minhas-pecas', icon: FiShoppingBag, label: 'Minhas Peças' },
    { path: '/meus-pagamentos', icon: FiDollarSign, label: 'Pagamentos' },
  ];

  return (
    <div className="layout">
      <aside className={`sidebar ${menuAberto ? 'aberto' : ''}`}>
        <div className="sidebar-header">
          <h1 className="logo">
            👶 Mãe pra Mãe
          </h1>
        </div>

        <nav className="sidebar-nav">
          {menuItens.map((item) => {
            const Icon = item.icon;
            const ativo = location.pathname === item.path;
            
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`nav-item ${ativo ? 'ativo' : ''}`}
                onClick={() => setMenuAberto(false)}
              >
                <Icon size={20} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="sidebar-footer">
          <div className="usuario-info">
            <div className="avatar">
              {usuario?.nome?.charAt(0).toUpperCase()}
            </div>
            <div className="usuario-detalhes">
              <p className="usuario-nome">{usuario?.nome}</p>
              <p className="usuario-tipo">{isAdmin() ? 'Administrador' : 'Parceiro'}</p>
            </div>
          </div>
          <button onClick={handleLogout} className="btn-logout">
            <FiLogOut size={18} />
            Sair
          </button>
        </div>
      </aside>

      <div className="main-content">
        <header className="topbar">
          <button 
            className="btn-menu-mobile"
            onClick={() => setMenuAberto(!menuAberto)}
          >
            <FiMenu size={24} />
          </button>
          <div className="topbar-info">
            <span className="bem-vindo">Olá, {usuario?.nome}! 👋</span>
          </div>
        </header>

        <main className="content">
          {children}
        </main>
      </div>

      {menuAberto && (
        <div 
          className="overlay-mobile"
          onClick={() => setMenuAberto(false)}
        />
      )}
    </div>
  );
};

export default Layout;
