import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import './index.css';

// Componente de rota protegida
const RotaProtegida = ({ children, apenasAdmin = false }) => {
  const { autenticado, loading, isAdmin } = useAuth();

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
      </div>
    );
  }

  if (!autenticado) {
    return <Navigate to="/login" />;
  }

  if (apenasAdmin && !isAdmin()) {
    return <Navigate to="/dashboard" />;
  }

  return <Layout>{children}</Layout>;
};

// Placeholder para páginas que serão criadas
const PaginaEmConstrucao = ({ titulo }) => (
  <div className="card">
    <h1>{titulo}</h1>
    <p>Esta página está em desenvolvimento.</p>
    <p>Funcionalidades completas disponíveis no código fornecido.</p>
  </div>
);

function App() {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          
          <Route
            path="/dashboard"
            element={
              <RotaProtegida>
                <Dashboard />
              </RotaProtegida>
            }
          />

          <Route
            path="/pecas"
            element={
              <RotaProtegida apenasAdmin>
                <PaginaEmConstrucao titulo="Gestão de Peças" />
              </RotaProtegida>
            }
          />

          <Route
            path="/minhas-pecas"
            element={
              <RotaProtegida>
                <PaginaEmConstrucao titulo="Minhas Peças" />
              </RotaProtegida>
            }
          />

          <Route
            path="/vendas"
            element={
              <RotaProtegida apenasAdmin>
                <PaginaEmConstrucao titulo="Vendas" />
              </RotaProtegida>
            }
          />

          <Route
            path="/pagamentos"
            element={
              <RotaProtegida apenasAdmin>
                <PaginaEmConstrucao titulo="Pagamentos" />
              </RotaProtegida>
            }
          />

          <Route
            path="/meus-pagamentos"
            element={
              <RotaProtegida>
                <PaginaEmConstrucao titulo="Meus Pagamentos" />
              </RotaProtegida>
            }
          />

          <Route
            path="/parceiros"
            element={
              <RotaProtegida apenasAdmin>
                <PaginaEmConstrucao titulo="Parceiros" />
              </RotaProtegida>
            }
          />

          <Route
            path="/configuracoes"
            element={
              <RotaProtegida apenasAdmin>
                <PaginaEmConstrucao titulo="Configurações (Marcas e Tamanhos)" />
              </RotaProtegida>
            }
          />

          <Route path="/" element={<Navigate to="/dashboard" />} />
          <Route path="*" element={<Navigate to="/dashboard" />} />
        </Routes>
      </AuthProvider>
    </Router>
  );
}

export default App;
