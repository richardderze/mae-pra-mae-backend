# ⚡ RAILWAY - GUIA RÁPIDO VISUAL

## 🎯 Em 3 Passos Simples:

---

### 1️⃣ CRIAR CONTAS (5 minutos)

```
railway.app → Login com GitHub
   ↓
github.com → Criar conta (se não tiver)
   ↓
Pronto! ✅
```

---

### 2️⃣ UPLOAD NO GITHUB (5 minutos)

```
GitHub → "+" → New repository
   ↓
Nome: mae-pra-mae
   ↓
Create repository
   ↓
"Upload files" → Arraste pasta backend/
   ↓
Commit changes ✅
```

---

### 3️⃣ DEPLOY NO RAILWAY (5 minutos)

```
Railway → New Project
   ↓
Deploy from GitHub → mae-pra-mae
   ↓
"+ New" → Database → PostgreSQL
   ↓
Configurar Variables:
  - DATABASE_URL (reference do Postgres)
  - JWT_SECRET (qualquer texto longo)
   ↓
Settings → Generate Domain
   ↓
PRONTO! Backend no ar! 🚀
```

URL exemplo: `https://seu-app.up.railway.app`

---

### 4️⃣ CRIAR ADMIN (2 minutos)

Use Postman, Insomnia ou Thunder Client:

```
POST https://seu-app.up.railway.app/api/auth/setup-admin

Body (JSON):
{
  "nome": "Admin",
  "email": "admin@test.com",
  "senha": "admin123"
}
```

---

### 5️⃣ FRONTEND NA VERCEL (5 minutos)

```
vercel.com → Login com GitHub
   ↓
New Project → mae-pra-mae
   ↓
Root Directory: frontend
   ↓
Add Environment Variable:
  REACT_APP_API_URL = https://seu-app.up.railway.app/api
   ↓
Deploy
   ↓
PRONTO! ✅
```

URL exemplo: `https://mae-pra-mae.vercel.app`

---

## ✅ CHECKLIST FINAL

- [ ] Conta Railway criada
- [ ] Conta GitHub criada
- [ ] Repositório mae-pra-mae criado
- [ ] Pasta backend enviada pro GitHub
- [ ] Projeto criado no Railway
- [ ] PostgreSQL adicionado
- [ ] Variáveis configuradas
- [ ] Domain gerado
- [ ] /api/health funciona
- [ ] Admin criado
- [ ] Frontend na Vercel
- [ ] Login funcionando

---

## 🎉 RESULTADO

**Backend:** https://seu-app.up.railway.app
**Frontend:** https://mae-pra-mae.vercel.app
**Banco:** PostgreSQL automático no Railway

**CUSTO TOTAL: R$ 0,00** 💰

---

## 📱 ACESSO

```
URL: https://mae-pra-mae.vercel.app
Email: admin@test.com
Senha: admin123
```

**Mude a senha após o primeiro login!**

---

**Tempo total: ~20 minutos** ⏱️
**Dificuldade: Fácil** 😊
**Custo: Gratuito** 🆓
